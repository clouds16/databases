CREATE TABLE NewLogins
(LoginName varchar(128));

INSERT NewLogins
VALUES ('BBrown'), ('CChaplin'), ('DDyer'), ('EEbbers');
