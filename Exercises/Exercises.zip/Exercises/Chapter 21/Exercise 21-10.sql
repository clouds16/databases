USE AP;

/*
You will need to change the path to the assembly in the following
statement depending on where you created your project.
*/

CREATE ASSEMBLY ApClrObjects
FROM 'C:\Murach\SQL Server 2012\Exercises\ApClrObjects\obj\Debug\ApClrObjects.dll';