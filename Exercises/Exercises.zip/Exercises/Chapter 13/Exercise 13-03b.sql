SELECT *
FROM VendorAddress
WHERE VendorID = 4;
