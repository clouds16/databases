SELECT *
FROM sys.foreign_keys;