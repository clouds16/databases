UPDATE Invoices
SET PaymentTotal = 600, PaymentDate = '2012-02-10'
WHERE InvoiceID = 7;