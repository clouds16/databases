﻿UPDATE Invoices
SET PaymentTotal = 500, PaymentDate = '2012-06-10'
WHERE InvoiceNumber = 'ABC-123';