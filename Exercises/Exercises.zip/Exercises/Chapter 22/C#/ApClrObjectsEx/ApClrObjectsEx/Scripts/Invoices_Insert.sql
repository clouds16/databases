﻿INSERT INTO Invoices
VALUES (7, 'ABC-123', '2012-05-01', 500, 0, 0, 1,
       '2012-05-31', NULL);