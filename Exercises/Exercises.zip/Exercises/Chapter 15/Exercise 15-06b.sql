USE AP;

SELECT *
FROM dbo.fnDateRange('12/10/11','12/20/11');
