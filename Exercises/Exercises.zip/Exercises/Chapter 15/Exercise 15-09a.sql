USE AP;

CREATE TABLE TestUniqueNulls
(RowID int IDENTITY NOT NULL,
 NoDupName varchar(20) NULL);
