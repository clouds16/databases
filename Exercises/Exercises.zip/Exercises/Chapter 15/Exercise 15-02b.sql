USE AP;

EXEC spBalanceRange @BalanceMin = 200, @BalanceMax = 1000;