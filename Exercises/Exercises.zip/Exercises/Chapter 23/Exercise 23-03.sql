USE AP;

INSERT INTO Parts
VALUES ('ABC123', 'water pump', 'D324');